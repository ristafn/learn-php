        <!-- sidebar -->
        <div class="col-3">
            <div class="p-3 pe-4">
                <form class="d-flex">
                    <input class="form-control me-2" type="search" placeholder="Cari sesuatu..." aria-label="Cari">
                    <button class="btn btn-warning" type="submit">Cari</button>
                </form>
                <br>
                <ul class="list-group">
                    <li class="list-group-item"><a href="index.php?page=views/menu/dataPegawai" class="text-dark text-decoration-none">Data Pegawai</a></li>
                    <li class="list-group-item"><a href="index.php?page=views/menu/aboutUs" class="text-dark text-decoration-none">About Us</a></li>
                </ul>
            </div>
        </div>
        <!-- end sidebar -->