<div class="bg-dark text-white rounded-3 border h-100 p-5">
    <h2>Gagal Login</h2>
    <p>username/password salah!</p>
    <br>
    <hr>
    <a href="index.php?page=views/menu/login" class="btn btn-warning">Login</a>
</div>